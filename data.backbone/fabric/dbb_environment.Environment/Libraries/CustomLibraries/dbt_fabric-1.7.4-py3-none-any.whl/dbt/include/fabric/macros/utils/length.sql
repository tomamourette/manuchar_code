{% macro fabric__length(expression) %}

    len( {{ expression }} )

{%- endmacro -%}
